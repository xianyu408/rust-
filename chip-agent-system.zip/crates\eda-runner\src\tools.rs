use anyhow::{anyhow, Context, Result};
use domain::SimulationSummary;
use serde::{Deserialize, Serialize};
use std::{
    path::{Path, PathBuf},
    process::Stdio,
    time::Duration,
};
use tokio::{process::Command, time::timeout};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationPlan {
    pub project_root: PathBuf,
    pub top: Option<String>,
    pub synthesis_top: Option<String>,
    pub rtl_files: Vec<PathBuf>,
    pub testbench_files: Vec<PathBuf>,
    pub use_yosys: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum EdaTool {
    Verilator,
    Icarus,
    Yosys,
    Ngspice,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommandSpec {
    pub tool: EdaTool,
    pub program: String,
    pub args: Vec<String>,
    pub cwd: PathBuf,
    pub timeout_secs: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolOutput {
    pub spec: CommandSpec,
    pub exit_code: Option<i32>,
    pub stdout: String,
    pub stderr: String,
    pub timed_out: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolAvailability {
    pub verilator: bool,
    pub iverilog: bool,
    pub yosys: bool,
    pub ngspice: bool,
}

#[derive(Debug, Clone)]
pub struct EdaRunner {
    pub default_timeout: Duration,
}

impl Default for EdaRunner {
    fn default() -> Self {
        Self {
            default_timeout: Duration::from_secs(120),
        }
    }
}

impl EdaRunner {
    pub async fn availability(&self) -> ToolAvailability {
        ToolAvailability {
            verilator: command_exists("verilator_bin").await || command_exists("verilator").await,
            iverilog: command_exists("iverilog").await,
            yosys: command_exists("yosys").await,
            ngspice: command_exists("ngspice_con").await || command_exists("ngspice").await,
        }
    }

    pub async fn run_digital_simulation(&self, plan: &SimulationPlan) -> Result<Vec<SimulationSummary>> {
        validate_paths(plan)?;

        let availability = self.availability().await;
        let mut summaries = Vec::new();

        if availability.iverilog {
            summaries.push(self.icarus_sim(plan).await?);
        } else if availability.verilator {
            let lint = self.verilator_lint(plan).await?;
            let lint_passed = lint.passed;
            summaries.push(lint);

            if lint_passed {
                let build = self.verilator_binary(plan).await?;
                let build_passed = build.passed;
                summaries.push(build);

                if build_passed {
                    summaries.push(self.verilator_run(plan).await?);
                }
            }
        } else {
            return Err(anyhow!(
                "No digital simulator found. Install Verilator or Icarus Verilog."
            ));
        }

        if plan.use_yosys {
            if availability.yosys {
                summaries.push(self.yosys_synth_check(plan).await?);
            } else {
                summaries.push(SimulationSummary {
                    passed: false,
                    tool: "yosys".to_string(),
                    command: "yosys".to_string(),
                    exit_code: None,
                    stdout: String::new(),
                    stderr: "Yosys requested but not found in PATH".to_string(),
                });
            }
        }

        Ok(summaries)
    }

    pub async fn run_spice_batch(&self, project_root: &Path, netlist: &Path) -> Result<SimulationSummary> {
        let spec = CommandSpec {
            tool: EdaTool::Ngspice,
            program: resolve_program(&["ngspice_con", "ngspice"]).await?,
            args: vec!["-b".to_string(), normalize_arg(netlist)],
            cwd: project_root.to_path_buf(),
            timeout_secs: self.default_timeout.as_secs(),
        };

        let output = self.run_command(spec).await?;
        Ok(output.into_summary())
    }

    async fn verilator_lint(&self, plan: &SimulationPlan) -> Result<SimulationSummary> {
        let mut args = vec!["--lint-only".to_string(), "-Wall".to_string()];
        args.extend(plan.rtl_files.iter().map(|path| normalize_arg(path)));
        args.extend(plan.testbench_files.iter().map(|path| normalize_arg(path)));

        let spec = CommandSpec {
            tool: EdaTool::Verilator,
            program: resolve_program(&["verilator_bin", "verilator"]).await?,
            args,
            cwd: plan.project_root.clone(),
            timeout_secs: self.default_timeout.as_secs(),
        };

        Ok(self.run_command(spec).await?.into_summary())
    }

    async fn verilator_binary(&self, plan: &SimulationPlan) -> Result<SimulationSummary> {
        let obj_dir = PathBuf::from("runs").join("verilator_obj");
        tokio::fs::create_dir_all(plan.project_root.join("runs")).await?;

        let mut args = vec![
            "--binary".to_string(),
            "--timing".to_string(),
            "--Mdir".to_string(),
            normalize_arg(&obj_dir),
        ];
        args.extend(plan.rtl_files.iter().map(|path| normalize_arg(path)));
        args.extend(plan.testbench_files.iter().map(|path| normalize_arg(path)));
        if let Some(top) = &plan.top {
            args.push("--top-module".to_string());
            args.push(top.clone());
        }

        let spec = CommandSpec {
            tool: EdaTool::Verilator,
            program: resolve_program(&["verilator_bin", "verilator"]).await?,
            args,
            cwd: plan.project_root.clone(),
            timeout_secs: self.default_timeout.as_secs(),
        };

        Ok(self.run_command(spec).await?.into_summary())
    }

    async fn verilator_run(&self, plan: &SimulationPlan) -> Result<SimulationSummary> {
        let executable = self.verilator_executable(plan).await?;
        let spec = CommandSpec {
            tool: EdaTool::Verilator,
            program: normalize_arg(&executable),
            args: Vec::new(),
            cwd: plan.project_root.clone(),
            timeout_secs: self.default_timeout.as_secs(),
        };

        Ok(self.run_command(spec).await?.into_summary())
    }

    async fn verilator_executable(&self, plan: &SimulationPlan) -> Result<PathBuf> {
        let top = plan
            .top
            .as_deref()
            .or_else(|| plan.testbench_files.first().and_then(|path| path.file_stem()).and_then(|stem| stem.to_str()))
            .or_else(|| plan.rtl_files.first().and_then(|path| path.file_stem()).and_then(|stem| stem.to_str()))
            .ok_or_else(|| anyhow!("cannot infer Verilator executable name"))?;

        let obj_dir = PathBuf::from("runs").join("verilator_obj");
        let mut candidates = vec![obj_dir.join(format!("V{top}"))];
        candidates.push(obj_dir.join(format!("V{top}.exe")));

        for candidate in candidates {
            if tokio::fs::metadata(plan.project_root.join(&candidate)).await.is_ok() {
                return Ok(candidate);
            }
        }

        Err(anyhow!("Verilator executable for top module {top} was not found"))
    }

    async fn icarus_sim(&self, plan: &SimulationPlan) -> Result<SimulationSummary> {
        let out_file = PathBuf::from("runs").join("sim.vvp");
        tokio::fs::create_dir_all(plan.project_root.join("runs")).await?;

        let mut compile_args = vec![
            "-g2012".to_string(),
            "-o".to_string(),
            normalize_arg(&out_file),
        ];
        compile_args.extend(plan.rtl_files.iter().map(|path| normalize_arg(path)));
        compile_args.extend(plan.testbench_files.iter().map(|path| normalize_arg(path)));

        let compile = self
            .run_command(CommandSpec {
                tool: EdaTool::Icarus,
                program: "iverilog".to_string(),
                args: compile_args,
                cwd: plan.project_root.clone(),
                timeout_secs: self.default_timeout.as_secs(),
            })
            .await?;

        if !compile.passed() {
            return Ok(compile.into_summary());
        }

        let run = self
            .run_command(CommandSpec {
                tool: EdaTool::Icarus,
                program: "vvp".to_string(),
                args: vec![normalize_arg(&out_file)],
                cwd: plan.project_root.clone(),
                timeout_secs: self.default_timeout.as_secs(),
            })
            .await?;

        Ok(run.into_summary())
    }

    async fn yosys_synth_check(&self, plan: &SimulationPlan) -> Result<SimulationSummary> {
        let mut script = String::new();
        for file in &plan.rtl_files {
            script.push_str(&format!("read_verilog -sv {}; ", normalize_arg(file)));
        }
        if let Some(top) = &plan.synthesis_top {
            script.push_str(&format!("hierarchy -check -top {}; ", shell_safe_token(top)));
        }
        script.push_str("proc; opt; check;");

        let spec = CommandSpec {
            tool: EdaTool::Yosys,
            program: "yosys".to_string(),
            args: vec!["-p".to_string(), script],
            cwd: plan.project_root.clone(),
            timeout_secs: self.default_timeout.as_secs(),
        };

        Ok(self.run_command(spec).await?.into_summary())
    }

    async fn run_command(&self, spec: CommandSpec) -> Result<ToolOutput> {
        tokio::fs::create_dir_all(&spec.cwd).await?;

        let mut cmd = Command::new(&spec.program);
        cmd.args(&spec.args)
            .current_dir(&spec.cwd)
            .kill_on_drop(true)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());

        let child = cmd
            .spawn()
            .with_context(|| format!("failed to spawn {}", spec.program))?;

        let timeout_duration = Duration::from_secs(spec.timeout_secs);
        let output = match timeout(timeout_duration, child.wait_with_output()).await {
            Ok(result) => result?,
            Err(_) => {
                return Ok(ToolOutput {
                    spec,
                    exit_code: None,
                    stdout: String::new(),
                    stderr: format!("command timed out after {}s", timeout_duration.as_secs()),
                    timed_out: true,
                });
            }
        };

        Ok(ToolOutput {
            spec,
            exit_code: output.status.code(),
            stdout: String::from_utf8_lossy(&output.stdout).to_string(),
            stderr: String::from_utf8_lossy(&output.stderr).to_string(),
            timed_out: false,
        })
    }
}

impl ToolOutput {
    fn passed(&self) -> bool {
        self.exit_code == Some(0) && !self.timed_out
    }

    fn into_summary(self) -> SimulationSummary {
        SimulationSummary {
            passed: self.passed(),
            tool: format!("{:?}", self.spec.tool).to_lowercase(),
            command: format!("{} {}", self.spec.program, self.spec.args.join(" ")),
            exit_code: self.exit_code,
            stdout: self.stdout,
            stderr: self.stderr,
        }
    }
}

async fn command_exists(program: &str) -> bool {
    let probe = if cfg!(windows) { "where.exe" } else { "which" };
    Command::new(probe)
        .arg(program)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .await
        .is_ok_and(|status| status.success())
}

async fn resolve_program(candidates: &[&str]) -> Result<String> {
    for candidate in candidates {
        if command_exists(candidate).await {
            return Ok((*candidate).to_string());
        }
    }

    Err(anyhow!("none of these programs were found in PATH: {candidates:?}"))
}

fn validate_paths(plan: &SimulationPlan) -> Result<()> {
    if plan.rtl_files.is_empty() {
        return Err(anyhow!("at least one RTL file is required"));
    }

    for path in plan.rtl_files.iter().chain(plan.testbench_files.iter()) {
        if path.is_absolute()
            || path
                .components()
                .any(|component| matches!(component, std::path::Component::ParentDir))
        {
            return Err(anyhow!("path must not contain parent directory components: {path:?}"));
        }
    }

    Ok(())
}

fn normalize_arg(path: &Path) -> String {
    path.to_string_lossy().replace('\\', "/")
}

fn shell_safe_token(value: &str) -> String {
    value
        .chars()
        .filter(|ch| ch.is_ascii_alphanumeric() || *ch == '_' || *ch == '-')
        .collect()
}
