use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use uuid::Uuid;

pub type ProjectId = Uuid;
pub type JobId = Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Project {
    pub id: ProjectId,
    pub name: String,
    pub root: PathBuf,
    pub created_at: DateTime<Utc>,
}

impl Project {
    pub fn new(name: impl Into<String>, root: PathBuf) -> Self {
        Self {
            id: Uuid::new_v4(),
            name: name.into(),
            root,
            created_at: Utc::now(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CreateProjectRequest {
    pub name: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DesignRequest {
    pub prompt: String,
    #[serde(default = "default_language")]
    pub language: String,
    #[serde(default = "default_target")]
    pub target: String,
    #[serde(default = "default_max_repair_rounds")]
    pub max_repair_rounds: u8,
}

fn default_language() -> String {
    "systemverilog".to_string()
}

fn default_target() -> String {
    "simulation".to_string()
}

fn default_max_repair_rounds() -> u8 {
    3
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulateRequest {
    pub top: Option<String>,
    pub synthesis_top: Option<String>,
    pub rtl_files: Vec<String>,
    pub testbench_files: Vec<String>,
    #[serde(default)]
    pub use_yosys: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RepairRequest {
    pub job_id: JobId,
    #[serde(default)]
    pub max_repair_rounds: u8,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Job {
    pub id: JobId,
    pub project_id: ProjectId,
    pub kind: JobKind,
    pub status: JobStatus,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl Job {
    pub fn new(project_id: ProjectId, kind: JobKind) -> Self {
        let now = Utc::now();
        Self {
            id: Uuid::new_v4(),
            project_id,
            kind,
            status: JobStatus::Queued,
            created_at: now,
            updated_at: now,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum JobKind {
    Design,
    Simulate,
    Repair,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum JobStatus {
    Queued,
    Running,
    Passed,
    Failed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JobCreated {
    pub job_id: JobId,
    pub project_id: ProjectId,
    pub status: JobStatus,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JobEvent {
    pub job_id: JobId,
    pub sequence: u64,
    pub level: EventLevel,
    pub message: String,
    pub at: DateTime<Utc>,
    pub data: Option<serde_json::Value>,
}

impl JobEvent {
    pub fn new(job_id: JobId, sequence: u64, level: EventLevel, message: impl Into<String>) -> Self {
        Self {
            job_id,
            sequence,
            level,
            message: message.into(),
            at: Utc::now(),
            data: None,
        }
    }

    pub fn with_data(mut self, data: serde_json::Value) -> Self {
        self.data = Some(data);
        self
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EventLevel {
    Info,
    Warning,
    Error,
    Artifact,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DesignArtifact {
    pub path: String,
    pub kind: ArtifactKind,
    pub content: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ArtifactKind {
    Rtl,
    Testbench,
    Spec,
    Constraint,
    Report,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DesignPackage {
    pub summary: String,
    pub artifacts: Vec<DesignArtifact>,
    pub assumptions: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationSummary {
    pub passed: bool,
    pub tool: String,
    pub command: String,
    pub exit_code: Option<i32>,
    pub stdout: String,
    pub stderr: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RepairSuggestion {
    pub reason: String,
    pub artifacts: Vec<DesignArtifact>,
    pub should_retry: bool,
}
