use anyhow::{anyhow, Result};
use async_trait::async_trait;
use domain::{ArtifactKind, DesignArtifact, DesignPackage, DesignRequest};

#[async_trait]
pub trait DesignAgent: Send + Sync + 'static {
    async fn generate(&self, request: &DesignRequest) -> Result<DesignPackage>;
}

#[derive(Debug)]
pub struct HybridDesignAgent {
    rig: Option<RigDesignAgent>,
    fallback: HeuristicDesignAgent,
}

impl Default for HybridDesignAgent {
    fn default() -> Self {
        Self {
            rig: RigDesignAgent::from_env(),
            fallback: HeuristicDesignAgent,
        }
    }
}

#[async_trait]
impl DesignAgent for HybridDesignAgent {
    async fn generate(&self, request: &DesignRequest) -> Result<DesignPackage> {
        if let Some(rig) = &self.rig {
            match rig.generate(request).await {
                Ok(package) => return Ok(package),
                Err(error) => tracing::warn!(error = %error, "Rig generation failed; using heuristic fallback"),
            }
        }

        self.fallback.generate(request).await
    }
}

#[derive(Debug, Clone)]
pub struct RigDesignAgent {
    model: String,
}

impl RigDesignAgent {
    pub fn from_env() -> Option<Self> {
        std::env::var("OPENAI_API_KEY").ok()?;
        Some(Self {
            model: std::env::var("CHIP_AGENT_MODEL").unwrap_or_else(|_| "gpt-4o".to_string()),
        })
    }
}

#[async_trait]
impl DesignAgent for RigDesignAgent {
    async fn generate(&self, request: &DesignRequest) -> Result<DesignPackage> {
        use rig::{
            client::{CompletionClient, ProviderClient},
            completion::Prompt,
            providers::openai,
        };

        let client = openai::Client::from_env()?;
        let agent = client.agent(self.model.as_str()).build();
        let prompt = design_prompt(request);
        let response = agent.prompt(prompt).await?;
        parse_design_package(&response)
    }
}

#[derive(Debug, Default)]
pub struct HeuristicDesignAgent;

#[async_trait]
impl DesignAgent for HeuristicDesignAgent {
    async fn generate(&self, request: &DesignRequest) -> Result<DesignPackage> {
        let prompt = request.prompt.to_ascii_lowercase();

        if prompt.contains("alu") {
            Ok(alu_package())
        } else if prompt.contains("counter") || prompt.contains("计数") {
            Ok(counter_package())
        } else {
            Ok(template_package(&request.prompt))
        }
    }
}

fn alu_package() -> DesignPackage {
    let rtl = r#"module alu8 (
    input  logic [7:0] a,
    input  logic [7:0] b,
    input  logic [2:0] op,
    output logic [7:0] y,
    output logic       zero
);
    always_comb begin
        unique case (op)
            3'd0: y = a + b;
            3'd1: y = a - b;
            3'd2: y = a & b;
            3'd3: y = a | b;
            3'd4: y = a ^ b;
            default: y = 8'h00;
        endcase
    end

    assign zero = (y == 8'h00);
endmodule
"#;

    let tb = r#"module alu8_tb;
    logic [7:0] a;
    logic [7:0] b;
    logic [2:0] op;
    logic [7:0] y;
    logic zero;

    alu8 dut (
        .a(a),
        .b(b),
        .op(op),
        .y(y),
        .zero(zero)
    );

    task automatic check(input [7:0] aa, input [7:0] bb, input [2:0] oo, input [7:0] expected);
        begin
            a = aa;
            b = bb;
            op = oo;
            #1;
            if (y !== expected) begin
                $display("FAIL op=%0d a=%0h b=%0h got=%0h expected=%0h", oo, aa, bb, y, expected);
                $finish(1);
            end
        end
    endtask

    initial begin
        check(8'h02, 8'h03, 3'd0, 8'h05);
        check(8'h05, 8'h03, 3'd1, 8'h02);
        check(8'hf0, 8'h0f, 3'd2, 8'h00);
        check(8'hf0, 8'h0f, 3'd3, 8'hff);
        check(8'haa, 8'h0f, 3'd4, 8'ha5);
        check(8'haa, 8'haa, 3'd4, 8'h00);
        if (!zero) begin
            $display("FAIL zero flag");
            $finish(1);
        end
        $display("PASS alu8");
        $finish;
    end
endmodule
"#;

    DesignPackage {
        summary: "Generated an 8-bit ALU with add/sub/and/or/xor and zero flag.".to_string(),
        assumptions: vec![
            "Combinational SystemVerilog module.".to_string(),
            "Operation encoding: 0 add, 1 sub, 2 and, 3 or, 4 xor.".to_string(),
        ],
        artifacts: vec![
            DesignArtifact {
                path: "src/alu8.sv".to_string(),
                kind: ArtifactKind::Rtl,
                content: rtl.to_string(),
            },
            DesignArtifact {
                path: "tb/alu8_tb.sv".to_string(),
                kind: ArtifactKind::Testbench,
                content: tb.to_string(),
            },
            DesignArtifact {
                path: "spec.md".to_string(),
                kind: ArtifactKind::Spec,
                content: "# ALU8\n\n8-bit combinational ALU generated from the design prompt.\n".to_string(),
            },
        ],
    }
}

fn counter_package() -> DesignPackage {
    let rtl = r#"module counter8 (
    input  logic       clk,
    input  logic       rst_n,
    input  logic       en,
    output logic [7:0] count
);
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            count <= 8'h00;
        end else if (en) begin
            count <= count + 8'h01;
        end
    end
endmodule
"#;

    let tb = r#"module counter8_tb;
    logic clk;
    logic rst_n;
    logic en;
    logic [7:0] count;

    counter8 dut (.clk(clk), .rst_n(rst_n), .en(en), .count(count));

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rst_n = 0;
        en = 0;
        #12;
        rst_n = 1;
        en = 1;
        repeat (3) @(posedge clk);
        #1;
        if (count != 8'h03) begin
            $display("FAIL count=%0h", count);
            $finish(1);
        end
        $display("PASS counter8");
        $finish;
    end
endmodule
"#;

    DesignPackage {
        summary: "Generated an 8-bit enabled counter with active-low reset.".to_string(),
        assumptions: vec!["Counter increments on each enabled rising clock edge.".to_string()],
        artifacts: vec![
            DesignArtifact {
                path: "src/counter8.sv".to_string(),
                kind: ArtifactKind::Rtl,
                content: rtl.to_string(),
            },
            DesignArtifact {
                path: "tb/counter8_tb.sv".to_string(),
                kind: ArtifactKind::Testbench,
                content: tb.to_string(),
            },
        ],
    }
}

fn template_package(prompt: &str) -> DesignPackage {
    let rtl = r#"module generated_block (
    input  logic clk,
    input  logic rst_n,
    output logic ready
);
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ready <= 1'b0;
        end else begin
            ready <= 1'b1;
        end
    end
endmodule
"#;

    let tb = r#"module generated_block_tb;
    logic clk;
    logic rst_n;
    logic ready;

    generated_block dut (.clk(clk), .rst_n(rst_n), .ready(ready));

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rst_n = 0;
        #12;
        rst_n = 1;
        repeat (2) @(posedge clk);
        #1;
        if (!ready) begin
            $display("FAIL ready not asserted");
            $finish(1);
        end
        $display("PASS generated_block");
        $finish;
    end
endmodule
"#;

    DesignPackage {
        summary: "Generated a minimal synchronous block because the prompt did not match a built-in pattern.".to_string(),
        assumptions: vec![format!("Original prompt: {prompt}")],
        artifacts: vec![
            DesignArtifact {
                path: "src/generated_block.sv".to_string(),
                kind: ArtifactKind::Rtl,
                content: rtl.to_string(),
            },
            DesignArtifact {
                path: "tb/generated_block_tb.sv".to_string(),
                kind: ArtifactKind::Testbench,
                content: tb.to_string(),
            },
        ],
    }
}

fn design_prompt(request: &DesignRequest) -> String {
    format!(
        r#"You are a senior IC design assistant.

Return only valid JSON matching this Rust/Serde shape:
{{
  "summary": "short description",
  "artifacts": [
    {{ "path": "src/name.sv", "kind": "rtl", "content": "SystemVerilog source" }},
    {{ "path": "tb/name_tb.sv", "kind": "testbench", "content": "SystemVerilog testbench" }},
    {{ "path": "spec.md", "kind": "spec", "content": "Markdown spec" }}
  ],
  "assumptions": ["list of assumptions"]
}}

Constraints:
- Use synthesizable SystemVerilog for RTL.
- Include a self-checking testbench.
- Keep paths relative and inside src/, tb/, reports/, or the project root.
- Do not include Markdown fences around the JSON.

Language: {language}
Target: {target}
Design request:
{prompt}
"#,
        language = request.language,
        target = request.target,
        prompt = request.prompt
    )
}

fn parse_design_package(response: &str) -> Result<DesignPackage> {
    let trimmed = response.trim();
    if let Ok(package) = serde_json::from_str::<DesignPackage>(trimmed) {
        return Ok(package);
    }

    let start = trimmed
        .find('{')
        .ok_or_else(|| anyhow!("Rig response did not contain a JSON object"))?;
    let end = trimmed
        .rfind('}')
        .ok_or_else(|| anyhow!("Rig response did not contain a complete JSON object"))?;

    serde_json::from_str::<DesignPackage>(&trimmed[start..=end])
        .map_err(|error| anyhow!("failed to parse Rig design JSON: {error}"))
}
