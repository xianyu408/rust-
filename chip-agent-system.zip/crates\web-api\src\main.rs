mod routes;
mod state;

use anyhow::Result;
use axum::{
    routing::{get, post},
    Router,
};
use std::{net::SocketAddr, path::PathBuf};
use tower_http::{cors::CorsLayer, trace::TraceLayer};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt, EnvFilter};

#[tokio::main]
async fn main() -> Result<()> {
    init_tracing();

    let state = state::AppState::new(PathBuf::from("workspaces"));
    tokio::fs::create_dir_all(&state.workspaces_root).await?;

    let app = Router::new()
        .route("/", get(routes::index))
        .route("/app", get(routes::index))
        .route("/health", get(routes::health))
        .route("/api/projects", post(routes::create_project))
        .route("/api/projects/{project_id}", get(routes::get_project))
        .route("/api/projects/{project_id}/design", post(routes::start_design))
        .route("/api/projects/{project_id}/simulate", post(routes::start_simulation))
        .route("/api/projects/{project_id}/repair", post(routes::start_repair))
        .route("/api/jobs/{job_id}", get(routes::get_job))
        .route("/api/jobs/{job_id}/events", get(routes::job_events))
        .route("/api/projects/{project_id}/artifacts", get(routes::list_artifacts))
        .route("/api/projects/{project_id}/files/{*path}", get(routes::read_project_file))
        .with_state(state)
        .layer(CorsLayer::permissive())
        .layer(TraceLayer::new_for_http());

    let addr: SocketAddr = std::env::var("CHIP_AGENT_BIND")
        .unwrap_or_else(|_| "127.0.0.1:8080".to_string())
        .parse()?;

    tracing::info!(%addr, "starting chip agent API");
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}

fn init_tracing() {
    let env_filter = EnvFilter::try_from_default_env()
        .unwrap_or_else(|_| EnvFilter::new("web_api=info,agent_core=info,eda_runner=info,tower_http=info"));

    tracing_subscriber::registry()
        .with(env_filter)
        .with(tracing_subscriber::fmt::layer())
        .init();
}
