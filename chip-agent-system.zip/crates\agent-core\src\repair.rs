use anyhow::Result;
use async_trait::async_trait;
use domain::{RepairSuggestion, SimulationSummary};

#[async_trait]
pub trait RepairAgent: Send + Sync + 'static {
    async fn suggest(&self, summaries: &[SimulationSummary]) -> Result<RepairSuggestion>;
}

#[derive(Debug, Default)]
pub struct HeuristicRepairAgent;

#[async_trait]
impl RepairAgent for HeuristicRepairAgent {
    async fn suggest(&self, summaries: &[SimulationSummary]) -> Result<RepairSuggestion> {
        let failed = summaries.iter().find(|summary| !summary.passed);
        let reason = failed
            .map(classify_failure)
            .unwrap_or_else(|| "No failing simulator summary was provided.".to_string());

        Ok(RepairSuggestion {
            reason,
            artifacts: Vec::new(),
            should_retry: false,
        })
    }
}

fn classify_failure(summary: &SimulationSummary) -> String {
    let log = format!("{}\n{}", summary.stdout, summary.stderr).to_ascii_lowercase();

    if log.contains("syntax error") {
        "Simulator reported a syntax error. Regenerate the affected RTL/testbench around the reported line.".to_string()
    } else if log.contains("width") {
        "Simulator reported a width mismatch. Check signal declarations and casts.".to_string()
    } else if log.contains("unsupported") {
        "Simulator reported unsupported syntax. Prefer synthesizable SystemVerilog accepted by Verilator/Icarus.".to_string()
    } else if summary.exit_code.is_none() {
        "Simulator did not return a normal exit code, likely due to timeout or missing tool.".to_string()
    } else {
        "Simulation failed. Inspect stdout/stderr and rerun after narrowing the failing assertion.".to_string()
    }
}

